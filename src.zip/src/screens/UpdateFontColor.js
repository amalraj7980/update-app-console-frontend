import { View, Text } from 'react-native'
import '../App.css';
import reactCSS from 'reactcss'
import React, { useState } from "react";
import { SketchPicker, ChromePicker } from 'react-color';


export default function UpdateFontColor() {
    return (
        <View>
            <Text>UpdateFontColor</Text>
        </View>
    )
}